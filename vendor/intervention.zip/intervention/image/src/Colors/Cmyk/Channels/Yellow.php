<?php

declare(strict_types=1);

namespace Intervention\Image\Colors\Cmyk\Channels;

class Yellow extends Cyan
{
}
