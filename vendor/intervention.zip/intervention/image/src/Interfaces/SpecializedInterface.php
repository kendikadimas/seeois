<?php

declare(strict_types=1);

namespace Intervention\Image\Interfaces;

interface SpecializedInterface
{
}
